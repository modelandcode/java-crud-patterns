package com.modelncode.crudpattern;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPatternApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPatternApplication.class, args);
	}
}
